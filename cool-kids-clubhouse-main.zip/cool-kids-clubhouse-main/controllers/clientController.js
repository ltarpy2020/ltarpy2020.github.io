//This is where the call back functions for the client side of the website will go
exports.index = (req, res)=>{
    res.render('./');
};